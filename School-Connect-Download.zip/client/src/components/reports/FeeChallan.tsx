import React from "react";
import apsLogo from '@assets/Army_Public_Schools_&_Colleges_System.svg_1765184706370.png';
import { Student, FeeChallan } from "@/lib/mockData";
import { format } from "date-fns";

interface FeeChallanProps {
  student: Student;
  challan: FeeChallan;
}

export const FeeChallanDocument = React.forwardRef<HTMLDivElement, FeeChallanProps>(
  ({ student, challan }, ref) => {
    
    const Copies = ["Bank Copy", "School Copy", "Student Copy"];

    // Use default breakdown if not present (backward compatibility)
    const breakdown = challan.breakdown || {
      tuitionFee: challan.amount,
      labCharges: 0,
      computerFee: 0,
      examFee: 0,
      otherCharges: 0,
      lateFee: 0
    };

    return (
      <div ref={ref} id="printable-content" className="w-full p-4 bg-white text-black text-xs font-sans">
        <div className="flex justify-between gap-4">
          {Copies.map((copyType, index) => (
            <div key={index} className="flex-1 border-2 border-dashed border-gray-300 p-4 rounded-sm">
              <div className="text-center border-b pb-2 mb-2">
                <div className="flex items-center justify-center gap-2 mb-1">
                  <img src={apsLogo} alt="Logo" className="h-10 w-10" />
                  <div className="text-left">
                    <h1 className="font-bold text-sm text-green-800">APSACS JPJ Cantt</h1>
                    <p className="text-[10px] text-gray-500">Army Public School & College</p>
                  </div>
                </div>
                <h2 className="font-bold uppercase tracking-wide mt-2">Fee Challan</h2>
                <p className="text-[10px] italic text-gray-400">{copyType}</p>
              </div>

              <div className="space-y-1.5 mb-4">
                <div className="flex justify-between">
                  <span className="font-semibold text-gray-500">Challan No:</span>
                  <span className="font-mono">{challan.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold text-gray-500">Issue Date:</span>
                  <span>{format(new Date(), "dd-MMM-yyyy")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold text-gray-500">Due Date:</span>
                  <span className="text-red-600 font-medium">{challan.dueDate}</span>
                </div>
              </div>

              <div className="bg-gray-50 p-2 rounded mb-4 space-y-1">
                <div className="flex justify-between border-b border-gray-200 pb-1">
                  <span className="text-gray-500">Roll No:</span>
                  <span className="font-bold">{student.rollNo}</span>
                </div>
                <div className="flex justify-between border-b border-gray-200 py-1">
                  <span className="text-gray-500">Name:</span>
                  <span className="font-medium uppercase">{student.name}</span>
                </div>
                <div className="flex justify-between border-b border-gray-200 py-1">
                  <span className="text-gray-500">Father:</span>
                  <span className="font-medium uppercase">{student.fatherName}</span>
                </div>
                <div className="flex justify-between pt-1">
                  <span className="text-gray-500">Class:</span>
                  <span>{student.class}</span>
                </div>
              </div>

              <div className="mb-4">
                <table className="w-full text-left">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="py-1 px-2">Description</th>
                      <th className="py-1 px-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="py-1 px-2 border-b">Tuition Fee</td>
                      <td className="py-1 px-2 border-b text-right">{breakdown.tuitionFee}</td>
                    </tr>
                    <tr>
                      <td className="py-1 px-2 border-b">Lab Charges</td>
                      <td className="py-1 px-2 border-b text-right">{breakdown.labCharges}</td>
                    </tr>
                    <tr>
                      <td className="py-1 px-2 border-b">Computer Fee</td>
                      <td className="py-1 px-2 border-b text-right">{breakdown.computerFee}</td>
                    </tr>
                    <tr>
                      <td className="py-1 px-2 border-b">Exam Fee</td>
                      <td className="py-1 px-2 border-b text-right">{breakdown.examFee}</td>
                    </tr>
                    <tr>
                      <td className="py-1 px-2 border-b">Other Charges</td>
                      <td className="py-1 px-2 border-b text-right">{breakdown.otherCharges}</td>
                    </tr>
                    <tr>
                      <td className="py-1 px-2 border-b">Late Fee</td>
                      <td className="py-1 px-2 border-b text-right">{breakdown.lateFee}</td>
                    </tr>
                    <tr className="font-bold bg-gray-50">
                      <td className="py-2 px-2">Total Payable</td>
                      <td className="py-2 px-2 text-right">Rs. {challan.amount}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="mt-8 pt-4 border-t border-gray-300 text-center">
                <p className="text-[9px] text-gray-400">Authorized Signature</p>
                <p className="text-[8px] mt-2 text-gray-400">
                  Please deposit fee before due date to avoid late payment surcharges.
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
);
