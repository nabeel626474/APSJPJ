import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Users,
  CreditCard,
  Settings,
  LogOut,
  UserCog,
} from "lucide-react";
import apsLogo from '@assets/Army_Public_Schools_&_Colleges_System.svg_1765184706370.png';
import { useAuth } from "@/hooks/useAuth";

export function Sidebar() {
  const [location, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const links = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/students", label: "Students", icon: Users },
    { href: "/fees", label: "Fee Management", icon: CreditCard },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  if (user?.role === "admin") {
    links.push({ href: "/users", label: "User Management", icon: UserCog });
  }

  const handleLogout = async () => {
    try {
      await fetch("/api/logout", { method: "POST" });
      queryClient.clear();
      setLocation("/");
      window.location.reload();
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <div className="h-screen w-64 bg-sidebar border-r border-sidebar-border flex flex-col fixed left-0 top-0 text-sidebar-foreground">
      <div className="p-6 flex items-center gap-3 border-b border-sidebar-border">
        <div className="h-12 w-12 bg-white rounded-lg flex items-center justify-center p-1 shrink-0">
          <img src={apsLogo} alt="APS Logo" className="h-full w-full object-contain" />
        </div>
        <div>
          <h1 className="font-heading font-bold text-sm leading-tight">APSACS</h1>
          <p className="text-[10px] text-sidebar-foreground/70">JPJ Cantt</p>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = location === link.href;
          return (
            <Link key={link.href} href={link.href} className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-md transition-all duration-200 group",
              isActive
                ? "bg-sidebar-primary text-sidebar-primary-foreground font-medium shadow-md"
                : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            )}>
                <Icon className={cn("h-5 w-5", isActive ? "text-sidebar-primary-foreground" : "text-sidebar-foreground/60 group-hover:text-sidebar-accent-foreground")} />
                {link.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 rounded-md text-red-300 hover:bg-red-500/10 hover:text-red-200 transition-colors w-full"
        >
          <LogOut className="h-5 w-5" />
          Logout
        </button>
      </div>
    </div>
  );
}
