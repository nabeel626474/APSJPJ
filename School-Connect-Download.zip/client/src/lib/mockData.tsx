import React, { createContext, useContext, useState, useEffect } from "react";
import { format } from "date-fns";

export type FeeBreakdown = {
  tuitionFee: number;
  labCharges: number;
  computerFee: number;
  examFee: number;
  otherCharges: number;
  lateFee: number;
};

export type Student = {
  id: string;
  name: string;
  fatherName: string;
  class: string;
  rollNo: string;
  contact: string;
  admissionDate: string;
  monthlyFee: number;
  defaultFeeBreakdown: FeeBreakdown;
};

export type FeeChallan = {
  id: string;
  studentId: string;
  month: string;
  breakdown: FeeBreakdown;
  amount: number;
  status: "pending" | "paid";
  dueDate: string;
  paidDate?: string;
};

type AppContextType = {
  students: Student[];
  fees: FeeChallan[];
  addStudent: (student: Omit<Student, "id">) => void;
  addStudentsBulk: (students: Omit<Student, "id">[]) => void;
  generateChallan: (studentId: string, month: string) => void;
  markFeePaid: (challanId: string) => void;
  getStudent: (id: string) => Student | undefined;
  getStudentByRollNo: (rollNo: string) => Student | undefined;
};

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEFAULT_BREAKDOWN: FeeBreakdown = {
  tuitionFee: 3000,
  labCharges: 0,
  computerFee: 0,
  examFee: 0,
  otherCharges: 0,
  lateFee: 0
};

const INITIAL_STUDENTS: Student[] = [
  {
    id: "1",
    name: "Ali Khan",
    fatherName: "Ahmed Khan",
    class: "10th",
    rollNo: "1001",
    contact: "0300-1234567",
    admissionDate: "2024-01-15",
    monthlyFee: 5000,
    defaultFeeBreakdown: {
      tuitionFee: 4000,
      labCharges: 500,
      computerFee: 300,
      examFee: 0,
      otherCharges: 200,
      lateFee: 0
    }
  },
  {
    id: "2",
    name: "Fatima Bibi",
    fatherName: "Muhammad Hussain",
    class: "9th",
    rollNo: "9005",
    contact: "0333-9876543",
    admissionDate: "2024-02-10",
    monthlyFee: 4500,
    defaultFeeBreakdown: {
      tuitionFee: 3500,
      labCharges: 500,
      computerFee: 300,
      examFee: 200,
      otherCharges: 0,
      lateFee: 0
    }
  },
  {
    id: "3",
    name: "Zainab Malik",
    fatherName: "Tariq Malik",
    class: "10th",
    rollNo: "1002",
    contact: "0321-4567890",
    admissionDate: "2024-01-20",
    monthlyFee: 5000,
    defaultFeeBreakdown: {
      tuitionFee: 4000,
      labCharges: 500,
      computerFee: 500,
      examFee: 0,
      otherCharges: 0,
      lateFee: 0
    }
  },
];

const INITIAL_FEES: FeeChallan[] = [
  {
    id: "f1",
    studentId: "1",
    month: "December 2025",
    breakdown: {
      tuitionFee: 4000,
      labCharges: 500,
      computerFee: 300,
      examFee: 0,
      otherCharges: 200,
      lateFee: 0
    },
    amount: 5000,
    status: "pending",
    dueDate: "2025-12-10",
  },
  {
    id: "f2",
    studentId: "2",
    month: "November 2025",
    breakdown: {
      tuitionFee: 3500,
      labCharges: 500,
      computerFee: 300,
      examFee: 200,
      otherCharges: 0,
      lateFee: 0
    },
    amount: 4500,
    status: "paid",
    dueDate: "2025-11-10",
    paidDate: "2025-11-08",
  },
];

const STORAGE_KEYS = {
  students: "apsacs_students",
  fees: "apsacs_fees"
};

function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const stored = localStorage.getItem(key);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error("Error loading from localStorage:", e);
  }
  return defaultValue;
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error("Error saving to localStorage:", e);
  }
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [students, setStudents] = useState<Student[]>(() => 
    loadFromStorage(STORAGE_KEYS.students, INITIAL_STUDENTS)
  );
  const [fees, setFees] = useState<FeeChallan[]>(() => 
    loadFromStorage(STORAGE_KEYS.fees, INITIAL_FEES)
  );

  useEffect(() => {
    saveToStorage(STORAGE_KEYS.students, students);
  }, [students]);

  useEffect(() => {
    saveToStorage(STORAGE_KEYS.fees, fees);
  }, [fees]);

  const addStudent = (student: Omit<Student, "id">) => {
    const newStudent = { ...student, id: Math.random().toString(36).substr(2, 9) };
    setStudents((prev) => [...prev, newStudent]);
  };

  const addStudentsBulk = (newStudents: Omit<Student, "id">[]) => {
    const studentsWithIds = newStudents.map((s) => ({
      ...s,
      id: Math.random().toString(36).substr(2, 9),
      defaultFeeBreakdown: (s as any).defaultFeeBreakdown || { ...DEFAULT_BREAKDOWN, tuitionFee: s.monthlyFee }
    }));
    setStudents((prev) => [...prev, ...studentsWithIds]);
  };

  const generateChallan = (studentId: string, month: string) => {
    const student = students.find((s) => s.id === studentId);
    if (!student) return;

    const breakdown = student.defaultFeeBreakdown;
    const totalAmount = Object.values(breakdown).reduce((a, b) => a + b, 0);

    const newChallan: FeeChallan = {
      id: Math.random().toString(36).substr(2, 9),
      studentId,
      month,
      breakdown: { ...breakdown },
      amount: totalAmount,
      status: "pending",
      dueDate: format(new Date(), "yyyy-MM-10"),
    };
    setFees((prev) => [...prev, newChallan]);
  };

  const markFeePaid = (challanId: string) => {
    setFees((prev) =>
      prev.map((f) =>
        f.id === challanId
          ? { ...f, status: "paid" as const, paidDate: format(new Date(), "yyyy-MM-dd") }
          : f
      )
    );
  };

  const getStudent = (id: string) => students.find((s) => s.id === id);
  
  const getStudentByRollNo = (rollNo: string) => students.find((s) => s.rollNo === rollNo);

  return (
    <AppContext.Provider
      value={{
        students,
        fees,
        addStudent,
        addStudentsBulk,
        generateChallan,
        markFeePaid,
        getStudent,
        getStudentByRollNo,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
}
