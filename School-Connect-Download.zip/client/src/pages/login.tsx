import { useState } from "react";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import generatedImage from '@assets/generated_images/modern_school_building_exterior_with_blue_sky.png';
import apsLogo from '@assets/Army_Public_Schools_&_Colleges_System.svg_1765184706370.png';

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.message || "Login failed");
        return;
      }

      await queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setLocation("/");
    } catch (err) {
      setError("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex w-1/2 bg-slate-900 relative items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
           <img 
            src={generatedImage} 
            alt="School Building" 
            className="w-full h-full object-cover opacity-60"
           />
           <div className="absolute inset-0 bg-primary/80 mix-blend-multiply" />
        </div>
        <div className="relative z-10 text-white p-12 max-w-lg text-center">
            <img src={apsLogo} alt="APS Logo" className="h-32 w-32 mx-auto mb-8 drop-shadow-lg" />
            <h1 className="text-4xl font-heading font-bold mb-4">APSACS</h1>
            <h2 className="text-2xl font-light mb-6 opacity-90">Army Public School and College<br/>JPJ Cantt</h2>
            <p className="text-lg text-white/80 leading-relaxed">
                Management Information System
            </p>
        </div>
      </div>

      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-background">
        <div className="w-full max-w-md space-y-8">
            <div className="text-center lg:text-left">
                <h2 className="text-3xl font-bold tracking-tight text-foreground">Admin Login</h2>
                <p className="mt-2 text-muted-foreground">Sign in to manage the school system</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              {error && (
                <div className="bg-destructive/10 text-destructive text-sm p-3 rounded-md">
                  {error}
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>

              <Button type="submit" className="w-full h-11 text-base shadow-lg" disabled={isLoading}>
                {isLoading ? "Signing in..." : "Sign in to Dashboard"}
              </Button>
            </form>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">
                  Or
                </span>
              </div>
            </div>

            <Link href="/parent/login" className={buttonVariants({ variant: "outline", className: "w-full h-11" })}>
                Login as Parent / Student
            </Link>
        </div>
      </div>
    </div>
  );
}
