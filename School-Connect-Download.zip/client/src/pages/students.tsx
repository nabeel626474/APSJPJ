import { useState, useRef, useEffect } from "react";
import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";
import { useApp, Student } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Upload, FileSpreadsheet, Search, Eye, User } from "lucide-react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import * as XLSX from "xlsx";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

const studentSchema = z.object({
  name: z.string().min(2, "Name is required"),
  fatherName: z.string().min(2, "Father Name is required"),
  class: z.string().min(1, "Class is required"),
  rollNo: z.string().min(1, "Roll No is required"),
  contact: z.string().min(10, "Valid contact is required"),
  // Fee Components
  tuitionFee: z.string().transform((val) => Number(val) || 0),
  labCharges: z.string().transform((val) => Number(val) || 0),
  computerFee: z.string().transform((val) => Number(val) || 0),
  examFee: z.string().transform((val) => Number(val) || 0),
  otherCharges: z.string().transform((val) => Number(val) || 0),
});

type StudentFormValues = z.infer<typeof studentSchema>;

export default function Students() {
  const { students, addStudent, addStudentsBulk } = useApp();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [viewStudent, setViewStudent] = useState<Student | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const form = useForm<StudentFormValues>({
    resolver: zodResolver(studentSchema),
    defaultValues: {
      tuitionFee: 0,
      labCharges: 0,
      computerFee: 0,
      examFee: 0,
      otherCharges: 0,
    },
  });

  // Watch fee values to calculate total in real-time
  const feeValues = useWatch({
    control: form.control,
    name: ["tuitionFee", "labCharges", "computerFee", "examFee", "otherCharges"],
  });

  const totalFee = feeValues.reduce((acc, val) => acc + (Number(val) || 0), 0);

  const onSubmit = (data: StudentFormValues) => {
    addStudent({
      name: data.name,
      fatherName: data.fatherName,
      class: data.class,
      rollNo: data.rollNo,
      contact: data.contact,
      admissionDate: new Date().toISOString().split("T")[0],
      monthlyFee: totalFee,
      defaultFeeBreakdown: {
        tuitionFee: data.tuitionFee,
        labCharges: data.labCharges,
        computerFee: data.computerFee,
        examFee: data.examFee,
        otherCharges: data.otherCharges,
        lateFee: 0,
      }
    });
    setIsAddOpen(false);
    form.reset();
    toast({
      title: "Student Added",
      description: `${data.name} has been successfully added.`,
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: "binary" });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      const data = XLSX.utils.sheet_to_json(ws) as any[];

      // Map excel data to student structure
      const mappedStudents = data.map((row: any) => {
        const tuitionFee = Number(row.TuitionFee || 3000);
        const labCharges = Number(row.LabCharges || 0);
        const computerFee = Number(row.ComputerFee || 0);
        const examFee = Number(row.ExamFee || 0);
        const otherCharges = Number(row.OtherCharges || 0);
        const total = tuitionFee + labCharges + computerFee + examFee + otherCharges;

        return {
          name: row.Name || row.name || "Unknown",
          fatherName: row.FatherName || row.father_name || "Unknown",
          class: row.Class || row.class || "N/A",
          rollNo: row.RollNo || row.roll_no || String(Math.floor(Math.random() * 1000)),
          contact: row.Contact || row.contact || "0000000000",
          monthlyFee: total,
          admissionDate: new Date().toISOString().split("T")[0],
          defaultFeeBreakdown: {
            tuitionFee,
            labCharges,
            computerFee,
            examFee,
            otherCharges,
            lateFee: 0
          }
        };
      });

      addStudentsBulk(mappedStudents);
      toast({
        title: "Bulk Upload Successful",
        description: `Added ${mappedStudents.length} students from Excel.`,
      });
    };
    reader.readAsBinaryString(file);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const filteredStudents = students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.rollNo.includes(searchTerm)
  );

  return (
    <div className="min-h-screen bg-muted/20">
      <Sidebar />
      <div className="pl-64">
        <Header title="Student Management" />
        <main className="p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div className="relative w-72">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or roll no..."
                className="pl-9 bg-card"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="flex gap-3">
              <input
                type="file"
                accept=".xlsx, .xls"
                className="hidden"
                ref={fileInputRef}
                onChange={handleFileUpload}
              />
              <Button
                variant="outline"
                className="gap-2"
                onClick={() => fileInputRef.current?.click()}
              >
                <FileSpreadsheet className="h-4 w-4" />
                Upload Excel
              </Button>

              <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
                <DialogTrigger asChild>
                  <Button className="gap-2 shadow-sm">
                    <Plus className="h-4 w-4" />
                    Add Student
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Student</DialogTitle>
                    <DialogDescription>
                      Enter student details and configure their default fee structure.
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 py-4">
                    
                    {/* Personal Info Section */}
                    <div className="space-y-4">
                        <h3 className="font-semibold text-sm text-foreground">Personal Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="name">Full Name</Label>
                                <Input id="name" {...form.register("name")} placeholder="Ali Khan" />
                                {form.formState.errors.name && (
                                <p className="text-xs text-destructive">{form.formState.errors.name.message}</p>
                                )}
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="fatherName">Father Name</Label>
                                <Input id="fatherName" {...form.register("fatherName")} placeholder="Ahmed Khan" />
                                {form.formState.errors.fatherName && (
                                <p className="text-xs text-destructive">{form.formState.errors.fatherName.message}</p>
                                )}
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="class">Class</Label>
                                <Input id="class" {...form.register("class")} placeholder="10th" />
                                {form.formState.errors.class && (
                                <p className="text-xs text-destructive">{form.formState.errors.class.message}</p>
                                )}
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="rollNo">Roll No</Label>
                                <Input id="rollNo" {...form.register("rollNo")} placeholder="1001" />
                                {form.formState.errors.rollNo && (
                                <p className="text-xs text-destructive">{form.formState.errors.rollNo.message}</p>
                                )}
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="contact">Contact No</Label>
                            <Input id="contact" {...form.register("contact")} placeholder="0300-1234567" />
                            {form.formState.errors.contact && (
                                <p className="text-xs text-destructive">{form.formState.errors.contact.message}</p>
                            )}
                        </div>
                    </div>

                    <Separator />

                    {/* Fee Structure Section */}
                    <div className="space-y-4">
                        <div className="flex items-center justify-between">
                            <h3 className="font-semibold text-sm text-foreground">Default Monthly Fee Structure</h3>
                            <div className="text-sm font-medium">Total: <span className="text-primary text-lg font-bold">Rs. {totalFee}</span></div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="tuitionFee">Tuition Fee</Label>
                                <Input id="tuitionFee" type="number" {...form.register("tuitionFee")} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="labCharges">Lab Charges</Label>
                                <Input id="labCharges" type="number" {...form.register("labCharges")} />
                            </div>
                        </div>

                        <div className="grid grid-cols-3 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="computerFee">Computer Fee</Label>
                                <Input id="computerFee" type="number" {...form.register("computerFee")} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="examFee">Exam Fee</Label>
                                <Input id="examFee" type="number" {...form.register("examFee")} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="otherCharges">Other Charges</Label>
                                <Input id="otherCharges" type="number" {...form.register("otherCharges")} />
                            </div>
                        </div>
                    </div>

                    <DialogFooter className="mt-6">
                      <Button type="submit" className="w-full">Save Student</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="rounded-md border bg-card shadow-sm">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Roll No</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Father Name</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Total Fee</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                      No students found.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell className="font-medium">{student.rollNo}</TableCell>
                      <TableCell>{student.name}</TableCell>
                      <TableCell>{student.fatherName}</TableCell>
                      <TableCell>{student.class}</TableCell>
                      <TableCell>{student.contact}</TableCell>
                      <TableCell>Rs. {student.monthlyFee}</TableCell>
                      <TableCell className="text-right">
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            className="gap-2 text-primary hover:text-primary/80"
                            onClick={() => setViewStudent(student)}
                        >
                            <Eye className="h-4 w-4" />
                            View Profile
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </main>
      </div>

      {/* View Student Profile Dialog */}
      <Dialog open={!!viewStudent} onOpenChange={(open) => !open && setViewStudent(null)}>
        <DialogContent className="sm:max-w-[600px]">
            {viewStudent && (
                <>
                <DialogHeader>
                    <DialogTitle>Student Profile</DialogTitle>
                    <DialogDescription>Detailed information for {viewStudent.name}</DialogDescription>
                </DialogHeader>
                
                <div className="space-y-6 py-4">
                    <div className="flex items-start gap-4">
                        <div className="h-20 w-20 bg-primary/10 rounded-full flex items-center justify-center border-2 border-primary/20">
                            <User className="h-10 w-10 text-primary" />
                        </div>
                        <div className="space-y-1">
                            <h2 className="text-2xl font-bold">{viewStudent.name}</h2>
                            <p className="text-muted-foreground">{viewStudent.class} | Roll No: {viewStudent.rollNo}</p>
                            <Badge variant="outline" className="mt-2 bg-emerald-50 text-emerald-700 border-emerald-200">Active Student</Badge>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="space-y-1">
                            <p className="text-muted-foreground text-xs uppercase font-semibold">Father Name</p>
                            <p className="font-medium">{viewStudent.fatherName}</p>
                        </div>
                        <div className="space-y-1">
                            <p className="text-muted-foreground text-xs uppercase font-semibold">Contact No</p>
                            <p className="font-medium">{viewStudent.contact}</p>
                        </div>
                        <div className="space-y-1">
                            <p className="text-muted-foreground text-xs uppercase font-semibold">Admission Date</p>
                            <p className="font-medium">{viewStudent.admissionDate}</p>
                        </div>
                    </div>

                    <Separator />

                    <div>
                        <h3 className="font-semibold mb-3">Fee Structure</h3>
                        <div className="bg-muted/30 rounded-lg border p-4">
                            <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Tuition Fee</span>
                                    <span className="font-medium">Rs. {viewStudent.defaultFeeBreakdown.tuitionFee}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Lab Charges</span>
                                    <span className="font-medium">Rs. {viewStudent.defaultFeeBreakdown.labCharges}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Computer Fee</span>
                                    <span className="font-medium">Rs. {viewStudent.defaultFeeBreakdown.computerFee}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Exam Fee</span>
                                    <span className="font-medium">Rs. {viewStudent.defaultFeeBreakdown.examFee}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Other Charges</span>
                                    <span className="font-medium">Rs. {viewStudent.defaultFeeBreakdown.otherCharges}</span>
                                </div>
                                <div className="border-t pt-2 mt-2 flex justify-between font-bold text-base">
                                    <span>Total Monthly Fee</span>
                                    <span className="text-primary">Rs. {viewStudent.monthlyFee}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </>
            )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
