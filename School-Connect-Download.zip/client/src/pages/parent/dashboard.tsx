import { useEffect, useState } from "react";
import { useLocation, Link } from "wouter";
import { useApp, Student } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import apsLogo from '@assets/Army_Public_Schools_&_Colleges_System.svg_1765184706370.png';
import { LogOut, User, Download } from "lucide-react";

export default function ParentDashboard() {
  const [_, setLocation] = useLocation();
  const { students, fees } = useApp();
  const [student, setStudent] = useState<Student | null>(null);

  useEffect(() => {
    const storedId = localStorage.getItem("parentStudentId");
    if (!storedId) {
      setLocation("/parent/login");
      return;
    }
    const found = students.find(s => s.id === storedId);
    if (found) {
        setStudent(found);
    } else {
        setLocation("/parent/login");
    }
  }, [students, setLocation]);

  if (!student) return null;

  const studentFees = fees.filter(f => f.studentId === student.id);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Parent Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3">
                <img src={apsLogo} alt="Logo" className="h-10 w-10" />
                <div>
                    <h1 className="font-bold text-primary leading-none">Parent Portal</h1>
                    <p className="text-xs text-muted-foreground">APSACS JPJ Cantt</p>
                </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setLocation("/parent/login")}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
            </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 space-y-6">
        {/* Student Profile Card */}
        <Card className="border-t-4 border-t-primary">
            <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row gap-6 items-start">
                    <div className="h-24 w-24 bg-gray-100 rounded-full flex items-center justify-center border-4 border-white shadow-sm shrink-0">
                        <User className="h-12 w-12 text-gray-400" />
                    </div>
                    <div className="space-y-1 flex-1">
                        <h2 className="text-2xl font-bold">{student.name}</h2>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                            <div>
                                <p className="text-xs text-muted-foreground uppercase font-semibold">Roll Number</p>
                                <p className="font-medium">{student.rollNo}</p>
                            </div>
                            <div>
                                <p className="text-xs text-muted-foreground uppercase font-semibold">Class</p>
                                <p className="font-medium">{student.class}</p>
                            </div>
                            <div>
                                <p className="text-xs text-muted-foreground uppercase font-semibold">Father Name</p>
                                <p className="font-medium">{student.fatherName}</p>
                            </div>
                            <div>
                                <p className="text-xs text-muted-foreground uppercase font-semibold">Admission Date</p>
                                <p className="font-medium">{student.admissionDate}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>

        {/* Fee History */}
        <Card>
            <CardHeader>
                <CardTitle>Fee History & Challans</CardTitle>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Month</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead>Due Date</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Action</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {studentFees.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                                    No fee records found.
                                </TableCell>
                            </TableRow>
                        ) : (
                            studentFees.map(fee => (
                                <TableRow key={fee.id}>
                                    <TableCell className="font-medium">{fee.month}</TableCell>
                                    <TableCell>Rs. {fee.amount}</TableCell>
                                    <TableCell>{fee.dueDate}</TableCell>
                                    <TableCell>
                                        <Badge variant={fee.status === "paid" ? "default" : "destructive"}
                                          className={fee.status === "paid" ? "bg-emerald-600" : ""}
                                        >
                                            {fee.status.toUpperCase()}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Button variant="outline" size="sm" className="h-8 gap-2">
                                            <Download className="h-3 w-3" />
                                            Download
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
      </main>
    </div>
  );
}
