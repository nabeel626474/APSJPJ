import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLocation, Link } from "wouter";
import apsLogo from '@assets/Army_Public_Schools_&_Colleges_System.svg_1765184706370.png';
import { useApp } from "@/lib/mockData";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function ParentLogin() {
  const [_, setLocation] = useLocation();
  const { students } = useApp();
  const [rollNo, setRollNo] = useState("");
  const { toast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple mock validation
    const student = students.find(s => s.rollNo === rollNo);
    
    if (student) {
      // In a real app we would use a proper auth token
      // For mock, we'll just pass the ID in the URL or state, 
      // but for security let's just assume we store it in a context/localstorage
      localStorage.setItem("parentStudentId", student.id);
      setLocation("/parent/dashboard");
    } else {
      toast({
        title: "Student Not Found",
        description: "Please enter a valid Roll Number (e.g., 1001, 9005)",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
      <div className="w-full max-w-md bg-white p-8 rounded-lg shadow-md border border-gray-100">
        <div className="text-center mb-8">
            <img src={apsLogo} alt="APS Logo" className="h-20 w-20 mx-auto mb-4" />
            <h1 className="text-2xl font-heading font-bold text-primary">Parent Portal</h1>
            <p className="text-muted-foreground text-sm">APSACS JPJ Cantt</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
                <Label htmlFor="rollNo">Student Roll Number</Label>
                <Input 
                  id="rollNo" 
                  placeholder="Enter Roll No (e.g. 1001)" 
                  value={rollNo}
                  onChange={(e) => setRollNo(e.target.value)}
                  required 
                  className="h-11" 
                />
            </div>

            <Button type="submit" className="w-full h-11 text-base">
                View Student Records
            </Button>
        </form>

        <div className="mt-6 text-center">
            <Link href="/" className="text-sm text-primary hover:underline">
                Back to Admin Login
            </Link>
        </div>
      </div>
    </div>
  );
}
