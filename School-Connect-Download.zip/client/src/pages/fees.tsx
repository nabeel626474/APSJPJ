import { useState, useRef } from "react";
import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";
import { useApp, FeeChallan, Student } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Printer, CheckCircle, FileText, Search, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import { FeeChallanDocument } from "@/components/reports/FeeChallan";
import { useReactToPrint } from "react-to-print";

export default function Fees() {
  const { students, fees, generateChallan, markFeePaid, getStudent } = useApp();
  const { toast } = useToast();
  const [isGenerateOpen, setIsGenerateOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<string>("");
  const [selectedMonth, setSelectedMonth] = useState<string>("December 2025");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "paid">("all");
  
  const [printChallanData, setPrintChallanData] = useState<{challan: FeeChallan, student: Student} | null>(null);
  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = useReactToPrint({
    contentRef: printRef,
    documentTitle: "Fee Challan",
    onAfterPrint: () => setPrintChallanData(null),
  });

  const triggerPrint = (challan: FeeChallan) => {
    const student = getStudent(challan.studentId);
    if (!student) return;
    
    setPrintChallanData({ challan, student });
    setTimeout(() => {
        handlePrint();
    }, 100);
  };

  const handleGenerate = () => {
    if (!selectedStudent) return;
    generateChallan(selectedStudent, selectedMonth);
    setIsGenerateOpen(false);
    toast({
      title: "Challan Generated",
      description: "Fee challan has been created successfully.",
    });
  };

  const filteredFees = fees.filter((fee) => {
    const student = getStudent(fee.studentId);
    if (!student) return false;
    
    const matchesSearch = searchQuery === "" || 
      student.rollNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || fee.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-muted/20">
      <Sidebar />
      <div className="pl-64">
        <Header title="Fee Management" />
        <main className="p-8 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-foreground">Fee Records</h2>
            <Dialog open={isGenerateOpen} onOpenChange={setIsGenerateOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2 shadow-sm">
                  <FileText className="h-4 w-4" />
                  Generate Challan
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Generate Fee Challan</DialogTitle>
                  <DialogDescription>
                    Create a fee slip for a student.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="space-y-2">
                    <Label>Select Student</Label>
                    <Select onValueChange={setSelectedStudent}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a student" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px]">
                        {students.map((s) => (
                          <SelectItem key={s.id} value={s.id}>
                            {s.name} ({s.rollNo})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Month</Label>
                    <Select onValueChange={setSelectedMonth} defaultValue="December 2025">
                      <SelectTrigger>
                        <SelectValue placeholder="Select month" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="October 2025">October 2025</SelectItem>
                        <SelectItem value="November 2025">November 2025</SelectItem>
                        <SelectItem value="December 2025">December 2025</SelectItem>
                        <SelectItem value="January 2026">January 2026</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleGenerate}>Generate</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by Roll No or Name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-10"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-md border bg-card shadow-sm">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Challan ID</TableHead>
                  <TableHead>Roll No</TableHead>
                  <TableHead>Student</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead>Month</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredFees.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                      {searchQuery ? "No fee records found matching your search" : "No fee records found"}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredFees.map((fee) => {
                    const student = getStudent(fee.studentId);
                    if (!student) return null;
                    return (
                      <TableRow key={fee.id}>
                        <TableCell className="font-mono text-xs">{fee.id}</TableCell>
                        <TableCell className="font-medium">{student.rollNo}</TableCell>
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell>{student.class}</TableCell>
                        <TableCell>{fee.month}</TableCell>
                        <TableCell>Rs. {fee.amount}</TableCell>
                        <TableCell>
                          <Badge
                            variant={fee.status === "paid" ? "default" : "destructive"}
                            className={fee.status === "paid" ? "bg-emerald-600 hover:bg-emerald-700" : ""}
                          >
                            {fee.status.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell>{fee.dueDate}</TableCell>
                        <TableCell className="text-right space-x-2">
                          {fee.status === "pending" && (
                            <Button
                              variant="outline"
                              size="icon"
                              title="Mark as Paid"
                              onClick={() => {
                                  markFeePaid(fee.id);
                                  toast({
                                      title: "Fee Paid",
                                      description: `Marked as paid for ${student.name}`
                                  })
                              }}
                            >
                              <CheckCircle className="h-4 w-4 text-emerald-600" />
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            title="Print Challan"
                            onClick={() => triggerPrint(fee)}
                          >
                            <Printer className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>

          <div className="hidden">
            <div ref={printRef}>
                {printChallanData && (
                    <FeeChallanDocument 
                        student={printChallanData.student} 
                        challan={printChallanData.challan} 
                    />
                )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
