# Persisted Information - Custom Login System

## User Request
User wants custom username/password login system instead of Replit Auth. Only they should be able to login. Data should be saved in database.

## Current Progress
1. ✅ Project files moved from `School-Connect-Prozip/School-Connect-Pro/` to root
2. ✅ PostgreSQL database created
3. ✅ Node.js 20 installed
4. ✅ bcryptjs installed for password hashing

## Remaining Tasks (from tasklist)
- Task 2: Database setup - need to update schema.ts to add username/password fields to users table
- Task 3: Create custom auth system - replace server/replitAuth.ts with custom passport-local authentication
- Task 4: Update login page - add username/password form fields in client/src/pages/login.tsx
- Task 5: Create default admin user - run script to create admin user

## Key Files to Modify

### 1. shared/schema.ts
Add username and password fields to users table:
```typescript
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").unique().notNull(),
  password: varchar("password").notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});
```

### 2. server/auth.ts (new file - replace replitAuth.ts)
Create custom passport-local authentication:
- Use bcryptjs for password hashing
- Session storage with connect-pg-simple
- Login/logout routes
- isAuthenticated middleware

### 3. server/routes.ts
Update to use new auth system instead of replitAuth

### 4. client/src/pages/login.tsx
Replace button with username/password form

### 5. client/src/hooks/useAuth.ts
Update to work with new auth system

## Default Admin Credentials
Username: admin
Password: admin123 (user should change this)

## Workflow Setup Required
After code changes:
- Command: `npm run dev`
- Port: 5000
- Output type: webview

## Database Push Command
After schema update: `npm run db:push`
